setlocal commentstring=#\ %s
